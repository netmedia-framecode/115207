<header class="header-section bg-ash">
  <div class="header-area">
    <div class="container">
      <div class="primary-menu">
        <div class="logo py-2">
          <a href="index.html"><img src="<?= $baseURL?>assets/img/logo.png" alt="logo"></a>
          <h5>Deo Gratias Farma</h5>
        </div>
        <div class="menu-bar d-lg-none">
          <i class="icofont-navigation-menu"></i>
        </div>
        <div class="main-area">
          <div class="main-menu d-flex flex-wrap align-items-center justify-content-center w-100">
            <ul class="lab-ul search-cart">
              <li>
                <div class="search-option" style="cursor: pointer;" onclick="window.location.href='auth/'">
                  <div class="icon icon-search"><i class="icofont-login"></i></div>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="shortcut icon" type="image/x-icon" href="<?= $baseURL?>assets/img/logo.png">
<link rel="stylesheet" href="<?= $baseURL?>assets/css/animate.css">
<link rel="stylesheet" href="<?= $baseURL?>assets/css/bootstrap.min.css">
<link rel="stylesheet" href="<?= $baseURL?>assets/css/icofont.min.css">
<link rel="stylesheet" href="<?= $baseURL?>assets/css/lightcase.css">
<link rel="stylesheet" href="<?= $baseURL?>assets/css/swiper.min.css">
<link rel="stylesheet" href="<?= $baseURL?>assets/css/style.css">
<title><?= $name_website?></title>
</div>
<!-- End of Main Content -->

<!-- Footer -->

<?php require_once("../sections/views_footer.php") ?>
<!-- End of Footer -->

</body>

</html>
